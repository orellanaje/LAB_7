#include <stdint.h>
#include <stdbool.h>
#include "inc/tm4c123gh6pm.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "driverlib/gpio.h"
#include "driverlib/timer.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"






        uint8_t var = 5;
        uint8_t var1 = 0;
       char rec = 0;
       char rec1 = 0;


        void setup (void);
        void toggle(uint32_t port, uint8_t pins);


  int main(void){
      setup();
      while(1)
      {

      }
  }

  void setup(void){

      SysCtlClockSet(SYSCTL_OSC_MAIN|SYSCTL_SYSDIV_5|SYSCTL_USE_PLL|SYSCTL_XTAL_16MHZ);//OSC A 40
      SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);// HABLITA PUERTO F
      GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3);// PINES 1,2 Y 3 COMO SALIDAS

      //TMER0

      SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);//HABILITA EL RELOJ PARA EL TEMP
      TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);// CONFIG temp periodico
      TimerLoadSet(TIMER0_BASE, TIMER_A, ((SysCtlClockGet()/2)- 1));// 0.5 seg, y se se quiere 1 seg se multiplica por 2
      IntEnable(INT_TIMER0A); // HABILITA EL TIMER A
      TimerEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
      TimerEnable(TIMER0_BASE, TIMER_A);

      //UART

      SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);//HABLITA PUERTO A
      SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);// PERIFERICO UART
      while(!SysCtlPeripheralReady(SYSCTL_PERIPH_UART0)){}// ESPERAR QUE ESTE LISTO
      UARTConfigSetExpClk(UART0_BASE, SysCtlClockGet(), 115200, UART_CONFIG_WLEN_8|UART_CONFIG_STOP_ONE|UART_CONFIG_PAR_NONE);
      GPIOPinConfigure(GPIO_PA0_U0RX);
      GPIOPinConfigure(GPIO_PA1_U0TX);
      GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
      IntEnable(INT_UART0);
      UARTIntEnable(UART0_BASE, UART_INT_RX | UART_INT_RT); // Hablito la interruop de Rx  y TX
      UARTEnable(UART0_BASE);

      //////

     IntMasterEnable();// All interrupp ON
  }

void UARTIntHandler (void){
    UARTIntClear(UART0_BASE, UART_INT_RX | UART_INT_RT);
    rec = UARTCharGet(UART0_BASE);
    if (rec1 != rec){
        if (rec == 'r') {
            var = 0;
            rec1 = rec;
        }else if (rec == 'g'){
            var = 2;
            rec1 = rec;
        }else if (rec == 'b'){
            var = 1;
            rec1 = rec;

        }
    }else{
        var = 5;
        rec1 = 0;
    }

}

void Timer0IntHandler(void){
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

    switch(var){
        case 0: // Para led ROJO
            toggle(GPIO_PORTF_BASE, GPIO_PIN_1);
            break;
        case 1: // Para led AZUL
            toggle(GPIO_PORTF_BASE, GPIO_PIN_2);
            break;
        case 2: // PAra led verde
            toggle(GPIO_PORTF_BASE, GPIO_PIN_3);
            break;
        default:
            GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, 0);
            break;

    }
}
void toggle (uint32_t port, uint8_t pins){
    switch(GPIOPinRead(port, pins)){
       case 0:
           GPIOPinWrite(port, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3, pins);
           break;
       default:
           GPIOPinWrite(port, GPIO_PIN_1 | GPIO_PIN_2 |GPIO_PIN_3, 0 );
           break;

    }
}






